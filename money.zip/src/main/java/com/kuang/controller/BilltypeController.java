package com.kuang.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author A102
 * @since 2021-12-29
 */
@Controller
@RequestMapping("/billtype")
public class BilltypeController {

}
